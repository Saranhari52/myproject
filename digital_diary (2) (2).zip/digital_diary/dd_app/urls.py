from django.urls import path
from django.conf import settings
from django.conf.urls.static import static
from dd_app import views

urlpatterns = [
    path("", views.home, name="home"),
    path("sidebar/", views.sidebar, name="sidebar"),

    # authentication
    path("signin/", views.signin, name="signin"),
    path("logout/", views.logout, name="logout"),
    path("signup/", views.signup, name="signup"),

    # profile
    path("profile/", views.profile, name="profile"),
    path('profile/update/<int:pk>/', views.profile_update, name='profile_update'),
    path("profile/details/add/", views.add_profile_details, name="add_profile_details"),
    path("profile/details/update/<int:pk>/", views.update_profile_details, name="update_profile_details"),

    # contacts
    path("contacts/", views.contact_list, name="contact_list"),
    path("contacts/update/<int:pk>/", views.contact_update, name="contact_update"),
    path("contacts/delete/<int:pk>/", views.contact_delete, name="contact_delete"),

    # income
    path("income/", views.income_list, name="income_list"),
    path("income/update/<int:id>/", views.income_update, name="income_update"),
    path("income/delete/<int:id>/", views.income_delete, name="income_delete"),

    # events
    path("events/", views.event_list, name="event_list"),
    path("events/add/", views.add_event, name="add_event"),
    path("events/update/", views.update_event, name="update_event"),
    path("events/delete/", views.delete_event, name="delete_event"),
    path("events/get/<int:id>/", views.get_event, name="get_event"),
    path("notes/get/", views.get_note, name="get_note"),
    path("notes/save/", views.save_note, name="save_note"),
    path("notes/dates/", views.note_dates, name="note_dates"),
    path("notes/delete/", views.delete_note, name="delete_note"),


    # expenses
    path("expenses/", views.expense_list, name="expense_list"),
    path("expenses/update/<int:id>/", views.expense_update, name="expense_update"),
    path("expenses/delete/<int:id>/", views.expense_delete, name="expense_delete"),

    # insurance
    path("insurance/", views.insurance_list, name="insurance_list"),
    path("insurance/add/", views.insurance_list, name="insurance_add"),
    path("insurance/update/<int:id>/", views.insurance_update, name="insurance_update"),
    path("insurance/delete/<int:id>/", views.insurance_delete, name="insurance_delete"),

    # investments
    path("investments/", views.investment_list, name="investment_list"),
    path("investments/add/", views.investment_list, name="investment_add"),
    path("investments/edit/<int:pk>/", views.investment_edit, name="investment_edit"),
    path("investments/delete/<int:pk>/", views.investment_delete, name="investment_delete"),

    # tax
    path("tax/", views.tax_list, name="tax_list"),
    path("tax/add/", views.tax_add, name="tax_add"),
    path("tax/update/<int:id>/", views.tax_update, name="tax_update"),
    path("tax/delete/<int:id>/", views.tax_delete, name="tax_delete"),

    # photos
    path("photos/", views.photo_gallery, name="photo_gallery"),
    path("photos/add/", views.add_photo, name="add_photo"),
    path("photos/edit/<int:pk>/", views.edit_photo, name="edit_photo"),
    path("photos/delete/<int:pk>/", views.delete_photo, name="delete_photo"),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
