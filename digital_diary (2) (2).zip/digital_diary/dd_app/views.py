from django.shortcuts import render, redirect, get_object_or_404
from .models import DiaryUser,DailyNote,Reminder,ProfileDetails,Contact,Event,Income,Expense,Investment,Insurance,Tax,Photo
from .forms import DiaryUserForm,ProfileDetailsForm,ContactForm,EventForm,IncomeForm,ExpenseForm,InvestmentForm,InsuranceForm,TaxForm,PhotoForm
from django.contrib import messages
from django.http import JsonResponse
import json
from django.views.decorators.csrf import csrf_exempt
from django.core.serializers.json import DjangoJSONEncoder
from django.db.models import Sum
from datetime import date,datetime,timedelta,timezone

# from django.contrib.auth.hashers import check_password

# ================= OTHER PAGES ==================
def home(request):
    return render(request,'home.html')

def sidebar(request):
    return render(request,'sidebar.html')


# ================= SIGN UP ==================
def signup(request):
    if request.method == "POST":
        form = DiaryUserForm(request.POST)
        if form.is_valid():
            # save password directly (plain text)
            form.save()
            messages.success(request, "Signup successful! Please login.")
            return redirect("signin")
    else:
        form = DiaryUserForm()
    return render(request, "signup.html", {"form": form})

# ================= SIGN IN ==================
def signin(request):
    if request.method == "POST":
        username = request.POST.get("username")
        password = request.POST.get("password")

        try:
            user = DiaryUser.objects.get(username=username, password=password)
            # store user session
            request.session["user_id"] = user.id
            messages.success(request, f"Welcome {user.username}!")
            return redirect("profile")

        except DiaryUser.DoesNotExist:
            messages.error(request, "Invalid username or password")
            return redirect("signin")
    return render(request, "signin.html")

from django.shortcuts import render, redirect, get_object_or_404
from .models import DiaryUser, ProfileDetails, Reminder, Event, Insurance, Tax
from .forms import ProfileForm, ProfileDetailsForm
from django.utils import timezone
from datetime import timedelta
from django.contrib.auth.hashers import make_password

def profile(request):
    user_id = request.session.get("user_id")
    if not user_id:
        return redirect("signin")

    user = get_object_or_404(DiaryUser, id=user_id)

    # ✅ AUTO CREATE if missing
    profile_details, created = ProfileDetails.objects.get_or_create(user=user)

    upcoming_events = Event.objects.filter(
        user=user, 
        date__gte=timezone.now()
    ).order_by("date")

    context = {
        "user": user,
        "profile_details": profile_details,
        "form": ProfileForm(instance=user),
        "details_form": ProfileDetailsForm(instance=profile_details),
        "upcoming_events": upcoming_events,
    }
    return render(request, "profile.html", context)

def profile_update(request, pk):
    user = get_object_or_404(DiaryUser, id=pk)
    if request.method == "POST":
        form = ProfileForm(request.POST, instance=user)
        if form.is_valid():
            user_obj = form.save(commit=False)
            password = form.cleaned_data.get('password')
            if password:
                user_obj.password = make_password(password)
            else:
                user_obj.password = DiaryUser.objects.get(id=user.id).password
            user_obj.save()
    return redirect("profile")


def add_profile_details(request):
    user_id = request.session.get("user_id")
    user = get_object_or_404(DiaryUser, id=user_id)
    if request.method == "POST":
        form = ProfileDetailsForm(request.POST, request.FILES)
        if form.is_valid():
            profile = form.save(commit=False)
            profile.user = user
            profile.save()
            return redirect("profile")
    else:
        form = ProfileDetailsForm()
    return render(request, "add_profile_details.html", {"form": form})


def update_profile_details(request, pk):
    details = get_object_or_404(ProfileDetails, id=pk)

    if request.method == "POST":
        form = ProfileDetailsForm(
            request.POST,
            request.FILES,
            instance=details
        )
        if form.is_valid():
            obj = form.save(commit=False)

            # ✅ preserve old values if empty
            for field in [
                "dob", "blood_group", "emergency_contact",
                "aadhaar_no", "voterid_no", "pan_no", "passbook_no"
            ]:
                if not getattr(obj, field):
                    setattr(obj, field, getattr(details, field))

            obj.save()
            return redirect("profile")

    return redirect("profile")
# ================= LOGOUT ==================
def logout(request):
    request.session.flush()
    messages.info(request, "You have been logged out.")
    return redirect("/")

# ===================================income=======================================

def income_list(request):
    user_id = request.session.get("user_id")
    if not user_id:
        return redirect("signin")

    user = get_object_or_404(DiaryUser, id=user_id)

    if request.method == "POST":
        form = IncomeForm(request.POST)
        if form.is_valid():
            income = form.save(commit=False)
            income.user = user  # assign actual user instance
            income.save()
            return redirect("income_list")
    else:
        form = IncomeForm()

    # ✅ Fix: update orphan contacts (only once, optional cleanup)
    Income.objects.filter(user__isnull=True).update(user=user)


    incomes = Income.objects.filter(user=user).order_by('-date')

    now = date.today()
    monthly_total = incomes.filter(
        date__year=now.year, date__month=now.month
    ).aggregate(Sum("amount"))["amount__sum"] or 0

    return render(request, "income.html", {
        "incomes": incomes,
        "form": form,
        "monthly_total": monthly_total,
        "now": now,
    })


def income_update(request, id):
    user_id = request.session.get("user_id")
    income = get_object_or_404(Income, id=id, user_id=user_id)

    if request.method == "POST":
        form = IncomeForm(request.POST, instance=income)
        if form.is_valid():
            form.save()
        return redirect("income_list")

    return redirect("income_list")


def income_delete(request, id):
    user_id = request.session.get("user_id")
    income = get_object_or_404(Income, id=id, user_id=user_id)
    income.delete()
    return redirect("income_list")
# ==============================expences==========================

def expense_list(request):
    user_id = request.session.get("user_id")
    if not user_id:
        return redirect("signin")

    user = get_object_or_404(DiaryUser, id=user_id)

    if request.method == "POST":
        form = ExpenseForm(request.POST)
        if form.is_valid():
            expense = form.save(commit=False)
            expense.user = user   # ✅ use DiaryUser from session
            expense.save()
            return redirect("expense_list")
    else:
        form = ExpenseForm()

    expenses = Expense.objects.filter(user=user).order_by("-date")

    now = date.today()
    monthly_total = expenses.filter(
        date__year=now.year, date__month=now.month
    ).aggregate(Sum("amount"))["amount__sum"] or 0

    return render(request, "expence.html", {
        "expenses": expenses,
        "form": form,
        "monthly_total": monthly_total,
        "now": now,
    })


def expense_update(request, id):
    user_id = request.session.get("user_id")
    if not user_id:
        return redirect("signin")

    user = get_object_or_404(DiaryUser, id=user_id)
    expense = get_object_or_404(Expense, id=id, user=user)

    if request.method == "POST":
        form = ExpenseForm(request.POST, instance=expense)
        if form.is_valid():
            form.save()
        return redirect("expense_list")

    return redirect("expense_list")


def expense_delete(request, id):
    user_id = request.session.get("user_id")
    if not user_id:
        return redirect("signin")

    user = get_object_or_404(DiaryUser, id=user_id)
    expense = get_object_or_404(Expense, id=id, user=user)
    expense.delete()
    return redirect("expense_list")
# =======================contact==================

def contact_list(request):
    user_id = request.session.get("user_id")
    if not user_id:
        return redirect("signin")

    # ✅ get the logged-in user
    user = get_object_or_404(DiaryUser, id=user_id)

    # ✅ Fix: update orphan contacts (only once, optional cleanup)
    Contact.objects.filter(user__isnull=True).update(user=user)

    # ✅ Now fetch only this user’s contacts
    contacts = Contact.objects.filter(user=user).order_by("id")

    if request.method == "POST":
        name = request.POST.get("name")
        relationship = request.POST.get("relationship")
        contact_no = request.POST.get("contact")
        email = request.POST.get("email")
        address = request.POST.get("address")

        Contact.objects.create(
            user=user,   # ✅ correct user
            name=name,
            relationship=relationship,
            contact=contact_no,
            email=email,
            address=address
        )
        return redirect("contact_list")

    return render(request, "contact.html", {"contacts": contacts})

# update
def contact_update(request, pk):
    # Get the logged-in user
    user_id = request.session.get("user_id")
    if not user_id:
        return redirect("login")  # Redirect if not logged in

    user = get_object_or_404(DiaryUser, id=user_id)

    # Get contact that belongs to this user
    contact = get_object_or_404(Contact, id=pk, user=user)

    if request.method == "POST":
        form = ContactForm(request.POST, instance=contact)
        if form.is_valid():
            form.save()
            return redirect("contact_list")
    else:
        form = ContactForm(instance=contact)

    return render(request, "contact_update.html", {"form": form})

# delete
def contact_delete(request, pk):
    user_id = request.session.get("user_id")
    if not user_id:
        return redirect("login")

    user = get_object_or_404(DiaryUser, id=user_id)

    # Only delete if the contact belongs to the logged-in user
    contact = get_object_or_404(Contact, id=pk, user=user)
    contact.delete()
    return redirect("contact_list")

# =============================================enevts====================================================

def event_list(request):
    user_id = request.session.get("user_id")
    if not user_id:
        return redirect("signin")

    user = get_object_or_404(DiaryUser, id=user_id)
    # Fetch all events and serialize them to a JSON string
    events = Event.objects.filter(user=user).values("id", "date", "name", "location", "description", "travel_mode", "status")
    
    # Use DjangoJSONEncoder to handle date objects correctly
    events_json = json.dumps(list(events), cls=DjangoJSONEncoder)
    
    return render(request, "events.html", {"events": events_json})

def get_event(request, id):
    event = get_object_or_404(Event, id=id)
    return JsonResponse(event.as_dict())
import json
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from .models import Event

def add_event(request):
    if request.method == "POST":
        data = json.loads(request.body)
        event = Event.objects.create(
            date=data.get("date"),
            name=data.get("name"),
            location=data.get("location"),
            description=data.get("description"),
            travel_mode=data.get("travel_mode"),
            status=data.get("status"),
            user_id=request.session["user_id"]  # session user
        )
        return JsonResponse({
            "event": {
                "id": event.id,
                "date": str(event.date),
                "name": event.name,
                "location": event.location,
                "description": event.description,
                "travel_mode": event.travel_mode,
                "status": event.status,
            }
        })

def update_event(request):
    if request.method == "POST":
        data = json.loads(request.body)
        event = Event.objects.get(id=data.get("id"))
        event.date = data.get("date")
        event.name = data.get("name")
        event.location = data.get("location")
        event.description = data.get("description")
        event.travel_mode = data.get("travel_mode")
        event.status = data.get("status")
        event.save()
        return JsonResponse({
            "event": {
                "id": event.id,
                "date": str(event.date),
                "name": event.name,
                "location": event.location,
                "description": event.description,
                "travel_mode": event.travel_mode,
                "status": event.status,
            }
        })

def delete_event(request):
    if request.method == "DELETE":
        data = json.loads(request.body)
        Event.objects.filter(id=data.get("id")).delete()
        return JsonResponse({"success": True})

from django.core.serializers import serialize
from django.http import JsonResponse
import json

def calendar_view(request):
    user_id = request.session.get("user_id")
    events = Event.objects.filter(user_id=user_id)

    # convert to list of dicts
    events_data = [
        {
            "id": e.id,
            "date": str(e.date),
            "name": e.name,
            "location": e.location,
            "description": e.description,
            "travel_mode": e.travel_mode,
            "status": e.status,
        }
        for e in events
    ]

    return render(request, "calendar.html", {
        "events_json": json.dumps(events_data)   # ✅ pass as safe JSON string
    })

def get_note(request):
    user_id = request.session.get("user_id")
    if not user_id:
        return JsonResponse({"error": "Login required"}, status=401)

    date = request.GET.get("date")
    note = DailyNote.objects.filter(user_id=user_id, date=date).first()

    return JsonResponse({"note": note.note if note else ""})

def save_note(request):
    user_id = request.session.get("user_id")
    if not user_id:
        return JsonResponse({"error": "Login required"}, status=401)

    data = json.loads(request.body)

    DailyNote.objects.update_or_create(
        user_id=user_id,
        date=data["date"],
        defaults={"note": data["note"]}
    )

    return JsonResponse({"success": True})

def note_dates(request):
    user_id = request.session.get("user_id")
    notes = DailyNote.objects.filter(user_id=user_id).values_list("date", flat=True)
    return JsonResponse({"dates": list(notes)})
from django.views.decorators.csrf import csrf_exempt

from django.views.decorators.http import require_POST

@require_POST
def delete_note(request):
    user_id = request.session.get("user_id")
    if not user_id:
        return JsonResponse({"error": "Login required"}, status=401)

    data = json.loads(request.body)

    DailyNote.objects.filter(
        user_id=user_id,
        date=data["date"]
    ).delete()

    return JsonResponse({"success": True})

# ==============================================insurence==========================================

def insurance_list(request):
    user_id = request.session.get("user_id")
    if not user_id:
        return redirect("signin")

    user = get_object_or_404(DiaryUser, id=user_id)
    insurances = Insurance.objects.filter(user=user).order_by('-due_date')

    if request.method == "POST":
        form = InsuranceForm(request.POST, request.FILES)  # ✅ handle files
        if form.is_valid():
            insurance = form.save(commit=False)
            insurance.user = user
            insurance.save()
            return redirect("insurance_list")
    else:
        form = InsuranceForm()

    return render(request, "insurance.html", {
        "insurances": insurances,
        "form": form,
    })


def insurance_update(request, id):
    user_id = request.session.get("user_id")
    insurance = get_object_or_404(Insurance, id=id, user_id=user_id)

    if request.method == "POST":
        form = InsuranceForm(request.POST, request.FILES, instance=insurance)  # ✅ handle files
        if form.is_valid():
            form.save()
            return redirect("insurance_list")
    return redirect("insurance_list")


def insurance_delete(request, id):
    user_id = request.session.get("user_id")
    insurance = get_object_or_404(Insurance, id=id, user_id=user_id)
    insurance.delete()
    return redirect("insurance_list")
# ===========================invevestment============================================================
def investment_list(request):
    user_id = request.session.get("user_id")
    if not user_id:
        return redirect("signin")

    user = get_object_or_404(DiaryUser, id=user_id)
    investments = Investment.objects.filter(user=user)

    if request.method == "POST":
        form = InvestmentForm(request.POST, request.FILES)
        if form.is_valid():
            investment = form.save(commit=False)
            investment.user = user
            investment.save()
            return redirect("investment_list")
    else:
        form = InvestmentForm()

    return render(request, "investment.html", {"form": form, "investments": investments})


def investment_edit(request, pk):
    investment = get_object_or_404(Investment, pk=pk)
    if request.method == "POST":
        form = InvestmentForm(request.POST, request.FILES, instance=investment)
        if form.is_valid():
            form.save()
            return redirect("investment_list")
    else:
        form = InvestmentForm(instance=investment)
    return render(request, "investment_form.html", {"form": form})


def investment_delete(request, pk):
    investment = get_object_or_404(Investment, pk=pk)
    investment.delete()
    return redirect("investment_list")

# =============================================tax===========================

def tax_list(request):
    user_id = request.session.get("user_id")
    if not user_id:
        return redirect("signin")

    user = get_object_or_404(DiaryUser, id=user_id)
    taxes = Tax.objects.filter(user=user).order_by("-date")

    if request.method == "POST":
        form = TaxForm(request.POST, request.FILES)
        if form.is_valid():
            tax = form.save(commit=False)
            tax.user = user
            tax.save()
            return redirect("tax_list")
    else:
        form = TaxForm()

    return render(request, "tax.html", {"taxes": taxes, "form": form})


def tax_add(request):
    user_id = request.session.get("user_id")
    if not user_id:
        return redirect("signin")

    user = get_object_or_404(DiaryUser, id=user_id)

    if request.method == "POST":
        form = TaxForm(request.POST, request.FILES)
        if form.is_valid():
            tax = form.save(commit=False)
            tax.user = user
            tax.save()
            return redirect("tax_list")
    return redirect("tax_list")


def tax_update(request, id):
    user_id = request.session.get("user_id")
    tax = get_object_or_404(Tax, id=id, user_id=user_id)

    if request.method == "POST":
        form = TaxForm(request.POST, request.FILES, instance=tax)
        if form.is_valid():
            form.save()
            return redirect("tax_list")
    return redirect("tax_list")


def tax_delete(request, id):
    user_id = request.session.get("user_id")
    tax = get_object_or_404(Tax, id=id, user_id=user_id)
    tax.delete()
    return redirect("tax_list")
# ==================================photo==========================

# ----------------- Gallery with filters -----------------
def photo_gallery(request):
    user_id = request.session.get("user_id")
    if not user_id:
        return redirect("signin")

    user = get_object_or_404(DiaryUser, id=user_id)

    photo_type = request.GET.get("type")
    start_date = request.GET.get("start_date")
    end_date = request.GET.get("end_date")

    # ✅ Only fetch photos of this user
    photos = Photo.objects.filter(user=user)

    if photo_type:
        photos = photos.filter(photo_type=photo_type)

    if start_date and end_date:
        photos = photos.filter(date__range=[start_date, end_date])

    form = PhotoForm()

    return render(request, "photo.html", {
        "photos": photos,
        "form": form,
    })


# ----------------- Add Photo -----------------
def add_photo(request):
    user_id = request.session.get("user_id")
    if not user_id:
        return redirect("signin")

    user = get_object_or_404(DiaryUser, id=user_id)

    if request.method == "POST":
        form = PhotoForm(request.POST, request.FILES)
        if form.is_valid():
            photo = form.save(commit=False)
            photo.user = user   # ✅ tie photo to logged-in user
            photo.save()
            return redirect("photo_gallery")
    return redirect("photo_gallery")


# ----------------- Edit Photo -----------------
def edit_photo(request, pk):
    user_id = request.session.get("user_id")
    if not user_id:
        return redirect("signin")

    photo = get_object_or_404(Photo, pk=pk, user_id=user_id)  # ✅ only user's photo
    if request.method == "POST":
        form = PhotoForm(request.POST, request.FILES, instance=photo)
        if form.is_valid():
            form.save()
            return redirect("photo_gallery")
    return redirect("photo_gallery")


# ----------------- Delete Photo -----------------
def delete_photo(request, pk):
    user_id = request.session.get("user_id")
    if not user_id:
        return redirect("signin")

    photo = get_object_or_404(Photo, pk=pk, user_id=user_id)  # ✅ only user's photo
    photo.delete()
    return redirect("photo_gallery")

# ================= USER LIST (ADMIN USE) ==================
# def user_list(request):
#     users = DiaryUser.objects.all()
#     return render(request, "user_list.html", {"users": users})
# def user_update(request, pk):
#     user = get_object_or_404(DiaryUser, pk=pk)
#     if request.method == "POST":
#         form = DiaryUserForm(request.POST, instance=user)
#         if form.is_valid():
#             form.save()
#             # refresh session username if this user is logged in
#             if request.session.get("user_id") == user.id:
#                 request.session["username"] = user.username
#             return redirect("profile")
#     else:
#         form = DiaryUserForm(instance=user)
#     return render(request, "user_update.html", {"form": form})

# ================= DELETE USER ==================
# def user_delete(request, pk):
#     user = get_object_or_404(DiaryUser, pk=pk)
#     if request.method == "POST":
#         user.delete()
#         return redirect("user_list")
#     return render(request, "user_confirm_delete.html", {"user": user})

