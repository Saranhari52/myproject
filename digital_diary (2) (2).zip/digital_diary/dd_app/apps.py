from django.apps import AppConfig


class DdAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'dd_app'
