from django.db import models
from django.conf import settings
from django.utils import timezone
# Create your models here.

class DiaryUser(models.Model):
    name = models.CharField(max_length=100)
    username = models.CharField(max_length=50, unique=True)
    password = models.CharField(max_length=128)  # Store hashed password
    email = models.EmailField(unique=True)
    contact = models.CharField(max_length=15)
    address = models.TextField()

    def __str__(self):
        return self.username
    
class ProfileDetails(models.Model):
    user = models.OneToOneField(
        DiaryUser,
        on_delete=models.CASCADE,
        related_name="profile_details"
    )
    dob = models.DateField(null=True, blank=True)
    blood_group = models.CharField(max_length=5, null=True, blank=True)
    emergency_contact = models.CharField(max_length=15, null=True, blank=True)
    aadhaar_no = models.CharField(max_length=20, null=True, blank=True)
    voterid_no = models.CharField(max_length=20, null=True, blank=True)
    pan_no = models.CharField(max_length=20, null=True, blank=True)
    passbook_no = models.CharField(max_length=20, null=True, blank=True)
    profile_pic = models.ImageField(
        upload_to="profile_pics/",
        default="default.png"
    )

    def __str__(self):
        return f"Details of {self.user.username}"

# contact
class Contact(models.Model):
    user = models.ForeignKey(
        "DiaryUser",
        on_delete=models.CASCADE,
        related_name="contacts"   # 👈 avoid clash
    )
    name = models.CharField(max_length=100)
    relationship = models.CharField(max_length=100)
    contact = models.CharField(max_length=15)
    email = models.EmailField()
    address = models.TextField()

    def __str__(self):
        return self.name
# events
class Event(models.Model):
    user = models.ForeignKey(DiaryUser, on_delete=models.CASCADE, related_name="events")
    date = models.DateField()
    name = models.CharField(max_length=200)
    location = models.CharField(max_length=200, blank=True, null=True)
    description = models.TextField(blank=True, null=True)
    travel_mode = models.CharField(max_length=50, blank=True, null=True)
    status = models.CharField(max_length=50, blank=True, null=True)

    def __str__(self):
        return f"{self.name} ({self.date})"

class DailyNote(models.Model):
    user = models.ForeignKey(DiaryUser, on_delete=models.CASCADE)
    date = models.DateField()
    note = models.TextField()

    class Meta:
        unique_together = ("user", "date")


class Income(models.Model):
    user = models.ForeignKey(DiaryUser, on_delete=models.CASCADE)
    date = models.DateField()
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    source = models.CharField(max_length=255)

    def __str__(self):
        return f"{self.user.username} - {self.amount} on {self.date}"

class Expense(models.Model):
    user = models.ForeignKey(DiaryUser, on_delete=models.CASCADE)
    date = models.DateField()
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    reason = models.CharField(max_length=255)

    def __str__(self):
        return f"{self.reason} - {self.amount}"
    
class Investment(models.Model):
    user = models.ForeignKey(DiaryUser, on_delete=models.CASCADE)
    date = models.DateField()
    amount = models.DecimalField(max_digits=12, decimal_places=2)
    description = models.TextField(blank=True, null=True)
    platform = models.CharField(max_length=100, choices=[
        ("Gold", "Gold"),
        ("Shares", "Shares"),
        ("Others", "Others")
    ], default="Others")
    proof = models.FileField(upload_to="investment_proofs/", blank=True, null=True)

    def __str__(self):
        return f"{self.user.username} - {self.amount} ({self.platform})"

class Insurance(models.Model):
    user = models.ForeignKey(DiaryUser, on_delete=models.CASCADE)
    insurance_name = models.CharField(max_length=200)
    policy_number = models.CharField(max_length=100, unique=True)
    premium_amount = models.DecimalField(max_digits=10, decimal_places=2)
    due_amount = models.DecimalField(max_digits=10, decimal_places=2)
    due_date = models.DateField()
    maturity_date = models.DateField()
    proof = models.FileField(upload_to="insurance_proofs/", blank=True, null=True)

    def __str__(self):
        return f"{self.insurance_name} - {self.policy_number}"
    
class Tax(models.Model):
    TAX_CHOICES = [
        ("property", "Property"),
        ("water", "Water"),
        ("under_drainage", "Under Drainage"),
        ("income", "Income"),
        ("nil", "Nil"),
    ]

    BILL_CHOICES = [
        ("rent", "Rent"),
        ("mobile", "Mobile"),
        ("emi", "EMI"),
        ("nil", "Nil"),
    ]

    user = models.ForeignKey(DiaryUser, on_delete=models.CASCADE)
    date = models.DateField()
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    tax_type = models.CharField(max_length=20, choices=TAX_CHOICES)
    bill_type = models.CharField(max_length=20, choices=BILL_CHOICES)
    proof = models.FileField(upload_to="tax_proofs/", blank=True, null=True)

    def __str__(self):
        return f"{self.tax_type} - {self.amount}"
    
class Photo(models.Model):
    PHOTO_TYPES = [
        ("1", "Family"),
        ("2", "Office"),
        ("3", "Trip"),
        ("4", "School"),
        ("5", "College"),
    ]
    
    user = models.ForeignKey(DiaryUser, on_delete=models.CASCADE)
    date = models.DateField()
    photo_type = models.CharField(max_length=10, choices=PHOTO_TYPES)
    image = models.ImageField(upload_to="photos/")

    def __str__(self):
        return f"{self.get_photo_type_display()} - {self.date}"
    
class Reminder(models.Model):
    user = models.ForeignKey(DiaryUser, on_delete=models.CASCADE, related_name="reminders")
    title = models.CharField(max_length=200)
    description = models.TextField(blank=True, null=True)
    date = models.DateField()
    time = models.TimeField(blank=True, null=True)  # optional
    is_done = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.title} on {self.date}"

