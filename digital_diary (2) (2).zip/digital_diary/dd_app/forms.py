from django import forms
from .models import DiaryUser,ProfileDetails,Contact,Event,Income,Expense,Investment,Insurance,Tax,Photo
from django.contrib.auth.hashers import make_password

class DiaryUserForm(forms.ModelForm):
    class Meta:
        model = DiaryUser
        fields = ['name', 'username', 'password', 'email', 'contact', 'address']
        widgets = {
            'password': forms.PasswordInput(),
        }
class ProfileForm(forms.ModelForm):
    class Meta:
        model = DiaryUser
        fields = ["name", "username", "password", "email", "address", "contact"]

class ProfileDetailsForm(forms.ModelForm):
    class Meta:
        model = ProfileDetails
        fields = ['dob', 'blood_group', 'emergency_contact', 'aadhaar_no', "voterid_no",  'pan_no', 'passbook_no', 'profile_pic']
        widgets = {
            'dob': forms.DateInput(attrs={'type': 'date'}),
        }

# contact
class ContactForm(forms.ModelForm):
    class Meta:
        model = Contact
        fields = ['name', 'relationship', 'contact', 'email', 'address']
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter name'}),
            'relationship': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter relationship'}),
            'contact': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter contact no'}),
            'email': forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'Enter email'}),
            'address': forms.Textarea(attrs={'class': 'form-control', 'rows': 2, 'placeholder': 'Enter address'}),
        }

# events

class EventForm(forms.ModelForm):
    class Meta:
        model = Event
        fields = ["date", "name", "location", "description", "travel_mode", "status"]
        widgets = {
            "date": forms.DateInput(attrs={"type": "date", "class": "form-control"}),
            "name": forms.TextInput(attrs={"class": "form-control", "placeholder": "Enter Event Name"}),
            "location": forms.TextInput(attrs={"class": "form-control", "placeholder": "Enter Location"}),
            "description": forms.Textarea(attrs={"class": "form-control", "rows": 2}),
            "travel_mode": forms.Select(attrs={"class": "form-select"}),
            "status": forms.Select(attrs={"class": "form-select"}),
        }

# income
class IncomeForm(forms.ModelForm):
    class Meta:
        model = Income
        fields = ['date', 'amount', 'source']
        widgets = {
            'date': forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'amount': forms.NumberInput(attrs={'step': '0.01', 'class': 'form-control'}),
            'source': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter income source'}),
        }

    def clean_amount(self):
        amount = self.cleaned_data.get('amount')
        if amount is None or amount <= 0:
            raise forms.ValidationError("Amount must be greater than zero.")
        return amount

# expence
class ExpenseForm(forms.ModelForm):
    class Meta:
        model = Expense
        fields = ["date", "amount", "reason"]
        widgets = {
            "date": forms.DateInput(attrs={"type": "date", "class": "form-control"}),
            "amount": forms.TextInput(attrs={"class": "form-control", "placeholder": "Enter expense Amount"}),
            "reason": forms.TextInput(attrs={"class": "form-control", "placeholder": "Enter expense Reason"}),
            }


class InvestmentForm(forms.ModelForm):
    class Meta:
        model = Investment
        fields = ["date", "amount", "description", "platform", "proof"]

class InsuranceForm(forms.ModelForm):
    class Meta:
        model = Insurance
        fields = [
            'insurance_name', 'policy_number', 'premium_amount',
            'due_amount', 'due_date', 'maturity_date','proof'
        ]
        widgets = {
            'insurance_name': forms.TextInput(attrs={'class': 'form-control'}),
            'policy_number': forms.TextInput(attrs={'class': 'form-control'}),
            'premium_amount': forms.NumberInput(attrs={'class': 'form-control'}),
            'due_amount': forms.NumberInput(attrs={'class': 'form-control'}),
            'due_date': forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'maturity_date': forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
        }

class TaxForm(forms.ModelForm):
    class Meta:
        model = Tax
        fields = ["date", "amount", "tax_type", "bill_type", "proof"]

class PhotoForm(forms.ModelForm):
    class Meta:
        model = Photo
        fields = ["date", "photo_type", "image"]


# class UserUpdateForm(forms.ModelForm):
#     class Meta:
#         model = DiaryUser
#         fields = ["name", "username", "password", "email", "address", "contact"]
#         widgets = {
#             "password": forms.PasswordInput(attrs={"class": "form-control"}),
#             "email": forms.EmailInput(attrs={"class": "form-control"}),
#             "address": forms.Textarea(attrs={"rows": 2, "class": "form-control"}),
#         }

    # def clean_password(self):
    #     password = self.cleaned_data.get("password")
    #     return make_password(password)   # Hash password before saving
